---
name: ai-driven-dev-workflow
description: Automated ticket-driven development using AI-Driven Development Workflow methodology. This skill should be used when converting specification documents into atomic tickets (2-4h each), executing tickets using TDD methodology (RED→GREEN→VERIFY), or managing ticket lifecycles with dependency tracking. Applies when users request ticket generation from specs, ticket execution with test-first development, or resuming from failed tickets.
---

# AI-Driven Development Workflow

## Overview

Automate software development using the AI-Driven Development Workflow methodology, transforming specifications into atomic, testable tickets and executing them through rigorous TDD cycles with built-in quality gates.

## Core Capabilities

### 1. Ticket Generation from Specifications

Convert specification documents into atomic tickets that can be completed in 2-4 hours each, following AI-Driven Development Workflow standards.

**When to use**: When a user provides a spec document and needs it broken down into executable tickets.

**Workflow**:
1. Read and analyze the specification document
2. Identify core requirements and features
3. Break down into atomic units (2-4h each)
4. Generate tickets using `assets/ticket-template.md`
5. Build dependency graph using `scripts/build_dependency_graph.py`
6. Create tickets/README.md index with execution plan
7. Validate all tickets using `scripts/validate_ticket.py`

**Validation criteria** (per ticket):
- Has `depends_on:` field
- Has Summary, Why, Scope, **Out-of-Scope** (CRITICAL)
- Has Acceptance Criteria (3-5 items, testable)
- Has Implementation Steps (concrete, with code examples)
- Has Test/Validation strategy
- Estimated time is 2-4h (exceptions allowed with justification)
- No circular dependencies

**Output structure**:
```
docs/tickets/{feature-name}/
├── README.md                    # Index with execution plan
├── dependencies.mermaid         # Visual dependency graph
├── ticket-001-{slug}.md
├── ticket-002-{slug}.md
└── ...
```

### 2. Ticket Execution with TDD

Execute tickets using strict Test-Driven Development through 6 phases: READ → RED → GREEN → VERIFY → DOCUMENT → COMMIT.

**When to use**: When tickets are ready for implementation and need to be executed following TDD methodology.

**Execution modes**:
- **Auto**: Execute all tickets sequentially without pausing (stop on failure)
- **Semi** (default): Pause after each phase for user review
- **Manual**: User selects which tickets to execute

**6-Phase Process** (per ticket):

#### Phase 1: READ - Understand Requirements
- Read ticket file completely
- Extract: Summary, AC, Implementation Steps, Test Strategy
- Verify all dependencies are ✅ Complete
- Mark ticket 🟡 Pending → 🔵 In Progress
- **Output**: Understanding summary with key information
- **Confirmation**: Ask to proceed (semi/manual mode)

#### Phase 2: RED - Write Failing Tests
- Create test file if doesn't exist
- Write tests based on Acceptance Criteria
- **CRITICAL**: Run tests to confirm they FAIL
- Verify failure reason is correct (not syntax errors)
- If tests pass immediately → revise tests (not testing new functionality)
- **Output**: Test file path, number of tests, failure confirmation
- **Confirmation**: Ask to proceed (semi/manual mode)

#### Phase 3: GREEN - Write Minimal Implementation
- Create/modify source files
- Write just enough code to make tests pass
- Run tests to confirm they PASS
- **Max 3 Attempts Rule**: If tests fail, retry up to 3 times
  - Attempt 1 fails → analyze and retry
  - Attempt 2 fails → analyze and retry
  - Attempt 3 fails → mark ticket 🔴 Blocked, generate failure report, STOP
- **Output**: Source file path, lines added, test pass confirmation, attempts count
- **Confirmation**: Ask to proceed (semi/manual mode)

#### Phase 4: VERIFY - Full Validation
Run comprehensive quality checks (CLAUDE.md Completion Checklist):

1. **Full test suite**: `pytest -v` (all tests must pass)
2. **Code coverage**: `pytest --cov={module} --cov-report=term-missing` (≥90% for new code)
3. **Type hints**: `mypy {source_file}` (no type errors)
4. **PEP 8 compliance**: `flake8 {source_file}` (no violations)
5. **Docstrings**: All public functions/classes must have docstrings
6. **Complexity**: Functions ~20 lines max, no premature optimization

Use `scripts/check_test_coverage.py` to automate coverage validation.

If any check fails:
- Increment attempt counter
- Fix issues
- Return to GREEN phase
- Apply Max 3 Attempts Rule

**Output**: Verification report with all check results
**Confirmation**: Ask to proceed (semi/manual mode)

#### Phase 5: DOCUMENT - Update Ticket and Docs
- Update ticket status: 🔵 In Progress → ✅ Complete
- Add timestamps (Started, Completed, Actual Time)
- Fill Execution Log section
- Update tickets/README.md progress
- Update related documentation if specified
- **Output**: Documentation update summary
- **Confirmation**: Ask to proceed to commit (semi/manual mode)

#### Phase 6: COMMIT - Atomic Commit
- Review changed files: `git status`, `git diff`
- Stage all relevant files
- Generate commit message following convention:
  ```
  {type}: {summary} (ticket-{ID})

  - Acceptance Criteria met: AC1, AC2, AC3
  - Tests: {X} new tests, all passing
  - Coverage: {XX}%

  Ticket: ticket-{ID}-{slug}.md

  🤖 Generated with [Claude Code](https://claude.com/claude-code)

  Co-Authored-By: Claude <noreply@anthropic.com>
  ```
  Where {type} is: feat / fix / refactor / test / docs
- Create commit: `git commit -m "{message}"`
- **Output**: Commit hash, message, files changed summary

### 3. Failure Handling and Recovery

Handle ticket failures gracefully with detailed reporting and recovery options.

**Max 3 Attempts Rule**:
```python
attempt = 0
max_attempts = 3

while attempt < max_attempts:
    result = execute_phase(phase)
    if result.success:
        break
    attempt += 1
    log_failure(phase, attempt, result.error)

if attempt >= max_attempts:
    mark_ticket_as_blocked()
    generate_failure_report()  # Use assets/failure-report-template.md
    stop_execution()
```

**Failure Report Contents** (using `assets/failure-report-template.md`):
- Summary of what failed
- Attempts log (all 3 attempts with errors and stacktraces)
- Root cause analysis
- Suggested fixes (multiple options)
- Impact assessment (blocked tickets, workarounds)
- Next steps for recovery

**Recovery Options**:
1. Fix issues manually and re-run specific ticket
2. Resume from failed ticket onward
3. Skip failed ticket and continue (if dependencies allow)

### 4. Dependency Management

Manage ticket dependencies and execution order automatically.

**Dependency Resolution**:
1. Parse all tickets' `depends_on:` fields
2. Build dependency graph (use `scripts/build_dependency_graph.py`)
3. Detect circular dependencies (error if found)
4. Calculate execution order (topological sort)
5. Group tickets into "waves" (parallel execution opportunities)

**Special Dependency Pattern** - "Analysis-first coordination":
- When ticket A needs to inform ticket B's design:
  - Ticket A includes "Step 0: Analysis Phase"
  - Ticket A outputs requirements document
  - Ticket B depends on "Ticket A analysis output"
  - Ticket B waits for analysis, not full implementation

## Usage Patterns

### Pattern 1: Generate Tickets from Spec

**User request**: "Generate tickets from docs/specs/my-feature.md"

**Process**:
1. Read specification document
2. Follow "Ticket Generation from Specifications" workflow
3. Output ticket files, README, dependency graph
4. Validate using `scripts/validate_ticket.py`
5. Report generation summary with validation results

### Pattern 2: Execute Tickets (Semi-Automatic)

**User request**: "Execute tickets in docs/tickets/my-feature/ with confirmation"

**Process**:
1. Scan tickets directory
2. Parse metadata (ID, dependencies, status, priority)
3. Build execution order
4. Display execution plan
5. Execute each ticket through 6-phase process
6. Pause after each phase for confirmation
7. Generate summary report when complete

### Pattern 3: Resume from Failure

**User request**: "Resume tickets from ticket-003"

**Process**:
1. Read failure report (if exists)
2. Check if ticket-003 is still 🔴 Blocked or fixed
3. If fixed, resume execution from ticket-003
4. If still blocked, show failure report and ask for guidance
5. Continue with remaining tickets in order

### Pattern 4: Execute Existing Tickets

**User request**: "Execute R15.1 through R15.3 tickets"

**Process**:
1. Locate specified tickets
2. Verify dependencies
3. Execute in order using TDD 6-phase process
4. Apply same quality gates and commit conventions

## Quality Standards

All executed tickets must meet these standards (from CLAUDE.md):

- [ ] All tests passing (100%)
- [ ] Code coverage ≥ 90% for new code
- [ ] Type hints present on all functions
- [ ] PEP 8 compliant (flake8 passes)
- [ ] Docstrings added (all public functions/classes)
- [ ] No unnecessary complexity (keep it simple)
- [ ] Atomic commit with clear message

## Resources

### scripts/

**`validate_ticket.py`** - Validates ticket structure against AI-Driven Development Workflow standards. Checks for required sections, Out-of-Scope presence, AC quality, and time estimates.

**`build_dependency_graph.py`** - Generates Mermaid dependency graph from tickets. Parses `depends_on:` fields, detects circular dependencies, groups tickets into parallel waves.

**`check_test_coverage.py`** - Automates test coverage validation. Runs pytest with coverage, parses results, verifies ≥90% for new code, returns pass/fail with detailed report.

### references/

**`ai-driven-workflow-standard.md`** - Complete AI-Driven Development Workflow specification. Load into context when ticket quality is questioned or user asks about standards.

**`tdd-workflow-guide.md`** - Detailed TDD (RED→GREEN→VERIFY) methodology guide. Load into context when executing tickets or user asks about TDD process.

**`ticket-quality-checklist.md`** - Comprehensive checklist for ticket quality assessment. Load into context when validating tickets or reviewing generated tickets.

### assets/

**`ticket-template.md`** - Standard ticket template following AI-Driven Development Workflow structure. Use when generating new tickets.

**`readme-template.md`** - Template for tickets/README.md index file. Use when generating ticket overview and execution plan.

**`failure-report-template.md`** - Template for detailed failure reports. Use when Max 3 Attempts reached or ticket execution blocked.

## Important Guidelines

### DO:
- Follow TDD strictly (RED → GREEN → VERIFY, always in order)
- Write tests BEFORE implementation (non-negotiable)
- Apply Max 3 Attempts Rule (know when to stop)
- Keep commits atomic (one ticket = one commit)
- Update ticket status in real-time
- Respect dependencies (never skip dependency checks)
- Generate detailed failure reports when blocked
- Validate ticket quality before execution

### DON'T:
- Skip the RED phase (tests must fail first)
- Write implementation before tests
- Commit failing tests or code
- Ignore quality checks (coverage, types, style)
- Continue after 3 failed attempts (STOP and report)
- Skip documentation updates
- Execute dependent tickets when dependencies blocked
- Generate tickets larger than 5h without strong justification

## Examples

### Example 1: Generate Tickets

**Input**: Spec document with 3 requirements (string normalization, vendor cleaning, amount extraction)

**Output**:
```
docs/tickets/string-utils/
├── README.md
├── dependencies.mermaid
├── ticket-001-setup-string-utils-module.md (2-3h)
├── ticket-002-implement-normalization.md (2-3h)
├── ticket-003-implement-vendor-cleaning.md (3-4h)
└── ticket-004-implement-amount-extraction.md (2-3h)

Total: 4 tickets, 9-13h estimated
Wave 1 (parallel): ticket-001, ticket-002, ticket-003, ticket-004
```

### Example 2: Execute Ticket

**Input**: ticket-002-implement-normalization.md

**Process**:
```
📖 [READ] Understanding requirements...
   Summary: Implement normalize_string() function
   AC: 3 criteria defined
   ✅ Ready to proceed

🔴 [RED] Writing tests...
   Created: tests/test_string_utils.py (3 tests)
   ❌ Tests failing as expected
   ✅ Ready to proceed

🟢 [GREEN] Writing implementation...
   Created: src/utils/string_utils.py
   ✅ All tests passing (3/3)
   Attempts: 1/3
   ✅ Ready to proceed

✅ [VERIFY] Running validations...
   Full suite: 125/125 passing ✅
   Coverage: 92% ✅
   Type hints: present ✅
   PEP 8: compliant ✅
   ✅ Ready to proceed

📝 [DOCUMENT] Updating ticket...
   Status: 🔵 → ✅
   Actual time: 2.5h
   ✅ Ready to commit

💾 [COMMIT] Committing changes...
   Hash: a1b2c3d
   Message: feat: implement string normalization (ticket-002)
   ✅ Complete
```

### Example 3: Handle Failure

**Input**: ticket-003 fails after 3 attempts

**Output**:
```
🚨 Ticket-003 FAILED after 3 attempts

Failure report generated:
docs/tickets/string-utils/ticket-003-failure-report.md

Root cause: UnicodeDecodeError in clean_vendor()
Suggested fix: Add explicit UTF-8 encoding

Blocked tickets:
- ticket-005: Depends on ticket-003

Next steps:
1. Review failure report
2. Apply suggested fix
3. Re-run: Execute ticket-003
```
